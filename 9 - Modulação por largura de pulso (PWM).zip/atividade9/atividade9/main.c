//Fernanda Chaves RA: 215835

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>


//Configuracao dos valores dos registradores referentes ao temporizador
unsigned char *pt_ocr2a = (unsigned char*) 0xB3;
unsigned char *pt_tccr2a = (unsigned char*) 0xB0;
unsigned char *pt_tccr2b = (unsigned char*) 0xB1;
unsigned char *pt_timsk2 = (unsigned char*) 0x70;

//ponteiros referentes ao pino do led
unsigned char *pt_ddrb = (unsigned char*) 0x24;


//Efetuando o c�lculo da formula dada em aula para descobrir um valor de faixa, foi obtido tal valor
//com um prescaler igual a 64 e um limite de 250, assim: faixa = 64*256/(16*10^6) = 1,024*10^-3s

//Percebe-se que aproximadamente a cada 4ms deve-se incrementar o duty cycle at� obter 256 em OCR2A para que o led realize o fade out
//e deve-se decrementar a cada 4ms o duty cycle at� obter 0 em OCR2A para que o led realize o fade in, ja que foi utilizado o
//modo invertido (978 / 256 = 4 aproximadamente)

//declaracao de variaveis auxiliares
volatile int valor_duty_cycle = 256;
volatile int count_led = 0;
volatile int fade = 0;
//0 - fade in
//1 - fade out
const int max_count_led = (978); //1000 / 1,024*10^-3 = 978 aproximadamente




void set_duty_cycle(volatile int valor_duty_cycle) {
	
	*pt_ocr2a = valor_duty_cycle;
}


ISR(TIMER2_OVF_vect){
	//incrementa toda vez que se passa uma faixa e a interrupcao e acionada
	
	//caso o contador de faixas tenha atigindo o limite, foi obtido o periodo de tempo desejado.
	//Assim, o led deve piscar e a contagem de faixas deve ser reiniciada
	//se flag for zero, deve-se iniciar o fade in
	count_led++;
	if(fade == 0) {
		if(count_led == (max_count_led)){
			fade = 1;
			valor_duty_cycle = 0;
		}
		
		//a cada quatro milisegundos quero que o valor do duty cycle seja incrementado at� o seu limite
		else if((count_led % 4) == 0){
			valor_duty_cycle = (valor_duty_cycle - 1) % 256;
			set_duty_cycle(valor_duty_cycle);
			
		}

	}
	//se flag for 1 inicia-se o fade out
	else if(fade == 1) {
		if((count_led) == (2*max_count_led)){
			fade = 0; //deve-se iniciar novamente o fade in
			count_led = 0; //reinicia a contagem ja que passou 1 seg
			valor_duty_cycle = 256; //retoma o valor m�ximo do duty cycle
		}
		//a cada quatro milisegundos quero que o valor do duty cycle seja incrementado at� o seu limite
		else if((count_led % 4) == 0){
			valor_duty_cycle = (valor_duty_cycle + 1) % 256;
			set_duty_cycle(valor_duty_cycle);
		}
		
	}

	

}



int main(){
	//configuro para o modo invertido no FAST PWM (mode 3)
	*pt_tccr2a = *pt_tccr2a | 0b11110011;
	*pt_tccr2b = *pt_tccr2b | 0b0000100;
	//ativo o modo de overflow
	*pt_timsk2 = *pt_timsk2 | 0b00000001;
	//defino PORTB como saida
	*pt_ddrb = 0xFF;
	sei(); //ativo interrupcoes globais
	
	while(1){
	}
}