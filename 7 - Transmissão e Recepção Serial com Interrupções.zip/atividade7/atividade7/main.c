/*
 * atividade7.c
 *
 * Created: 18/10/2019 15:10:11
 * Author : Fernanda Esteves (RA: 215835)
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
//Cria-se ponteiros para cada registrador referente a USART que deve ser configurado para a transmissao da mensagem bem como para a porta utizada pelo led
unsigned char *pt_ubrr0h = (unsigned char*) 0xC5;
unsigned char *pt_ubrr0l = (unsigned char*) 0xC4;
unsigned char *pt_ucsr0a = (unsigned char*) 0xC0;
unsigned char *pt_ucsr0b = (unsigned char*) 0xC1;
unsigned char *pt_ucsr0c = (unsigned char*) 0xC2;
unsigned char *pt_udr0 = (unsigned char*) 0xC6;
unsigned char *pt_ddrb = (unsigned char*) 0x24; //led
unsigned char *pt_portb = (unsigned char*) 0x25;

//cria-se uma matriz com todas as mensagens possiveis a serem enviadas a porta serial
char mensagens[9][60] = {"Comando: Acender LED - cor vermelha\n\0","Comando: Acender LED - cor verde\n\0", "Comando: Acender LED - cor azul\n\0","Comando: Acender LED - cor amarela\n\0", "Comando: Acender LED - cor ciano\n\0", "Comando: Acender LED - cor magenta\n\0", "Comando: Acender LED - cor branca\n\0","Comando incorreto\n\0", "Vazio!\n\0"};

//-----------------------------------------BUFFER CIRCULAR-------------------------------------------------------------------------------
char buffer_comando[10];  // declara�ao do buffer (vetor)
int next_c = 0; //proxima posi�ao livre para gravar
int pos_c = 0; // posi��o do elemento mais antigo
int count_c = 0; // vari�vel contadora que ser� incrementada caso seja adicionado algo no vetor e decrementada caso algo seja apagado do vetor

void adicionar_buffer_comando(char c) {
  if (!(next_c == pos_c && count_c == 10)) {//checa se o vetor est� cheio; sen�o entra no if para adicionar elementos
      buffer_comando[next_c] = c;
      next_c = (next_c+1) % 10;
    //esta opera��o acima faz com que o vetor next avance uma casa apos adicionar algo ao vetor, por�m de forma circular
      // assim ao efetuar tal opera��o, � atribuido a next o resto da divisao entre next+1 e 10, pois quando next estiver na
      //untima posi��o, deve voltar ao inicio do vetor
      count_c ++;
//incrementa a vari�vel contadora toda vez que algo � adicionado ao vetor
  }
}

void remover_buffer_comando() {
  if(!(next_c == pos_c && count_c == 0)) {//checa se o buffer est� vazio; sen�o, entra no if para remover itens
    pos_c = (pos_c + 1) % 10;//avan�a com a posi��o do mais antigo item do vetor
    count_c --;
// decresce a vari�vel contadora que indica o numero de itens no vetor, j� que algo ser� removido
  }
}


//-----------------------------------------------------------------------------------------------------------------------------------

//vetor que contem as possibilidades de cores a serem enviadas ao led
unsigned char led[8] = {0x00, 0x01, 0x02, 0x04, 0x03, 0x06, 0x05, 0x07};
//indicara qual elemento do vetor, isto �, qual mensagem deve ser enviada	
volatile int flag = 0;
//variavel que ira confirmar o envio total de uma mesagem e assim permitir que outros elementos do buffer sejam checados
volatile int mensagem_enviada = 0;
//variavel que percorrera a mensagem a ser enviada e que permitira o envio de cada caractere ao udr0
volatile int count_msg = 0;

//Interrupcoes
ISR(USART_RX_vect) {
	adicionar_buffer_comando(*pt_udr0);
	//somente adiciona-se o comando desejado ao buffer
};

ISR(USART_TX_vect){
	//caso a mensagem a ser enviada ainda n�o tenha chegado ao seu fim, sera enviado um caractere a udr0 e a variavel contadora de caractere sera incrementada
	//alem disso, mantem-se "mensagem_enviada = 1" pois indica que a mensagem ainda nao foi completamente enviada
	if(mensagens[flag][count_msg] != '\0'){
		mensagem_enviada = 1;
		(*pt_udr0) = mensagens[flag][count_msg];
		count_msg = count_msg + 1;
	}
	else{
		//zera-se "mensagem enviada" simbolizando assim, que a mensagem foi enviada completamente e zera-se a variavel contadora de caractere para que possa percorrer novas mensagens do inicio
		mensagem_enviada = 0;
		count_msg = 0;  	}
	
};

int main () {
	//Para definir o baund rate deve-se configurar o registrador UBRR0 do seguinte modo:
	//UBRR0H = 0;
	*pt_ubrr0h = *pt_ubrr0h & 0xF0;
	//UBRR0L = 0b01100111;
	*pt_ubrr0l = 0b01100111;
	
	//Para desabilitar o double speed e o modo de comunicacao multi-processador deve-se zerar os bits 1 e 0 do registrador UCSR0A
	//UCSR0A = 0x00;
	*pt_ucsr0a = *pt_ucsr0a & 0xFC;
	
	//Para habilitar a recepcao e transmissao completa bem como o receptor e o transmissor configura-se UCSR0B da seguinte forma: 1101 1000
	*pt_ucsr0b = 0xD8; 
	
	//Para que o modo de operacao da usart seja assincrono, nao tenha bit de paridade, use 2 bits de parada e tenha um frame de 8 bits configura-se UCSR0C da seguinte forma: 0b00001110;
	*pt_ucsr0c = 0b00001110;
//Para configurar os pinos da porta B como pinos de entrada
	(*pt_ddrb) = *pt_ddrb | 0x07;
	
	//Habita-se todas as interrupcoes globais
	sei();



 
while(1) {
	//se a mensagem anterior foi totalmente enviada, � permitido chegar o proximo elemento do buffer para evitar a sobreescricao
	if(mensagem_enviada == 0){

//para ativar a transmissao, e enviado um enter ("\n") para indicar a usart que a interrupcao pode ser utilizada

	//checa se o buffer esta vazio
	if((next_c == pos_c && count_c == 0) ) {
		*pt_udr0 = '\n';
		flag = 8; //mensagem referente ao comando vazio
		(*pt_portb) = led[0]; //led apagado
	}
	//checa se o comando referente a cor vermelha foi acionado
	else if(buffer_comando[pos_c] == 'r') {
			remover_buffer_comando();
			*pt_udr0 = '\n';
			flag = 0;	//mensagem referente ao comando da cor vermelha
			(*pt_portb) = led[1]; //led vermelho
		}	
	//checa se o comando referente a cor verde foi acionado
	else if(buffer_comando[pos_c] == 'g') {
			remover_buffer_comando();
			*pt_udr0 = '\n';
			flag = 1;//mensagem referente ao comando da cor verde	
			(*pt_portb) = led[2]; //led verde
	}
//checa se o comando referente a cor azul foi acionado
	else if(buffer_comando[pos_c] == 'b') {
		remover_buffer_comando();
		*pt_udr0 = '\n';
		flag = 2;	//mensagem referente ao comando da cor azul
			(*pt_portb) = led[3]; //led azul
	}
	//checa se o comando referente a cor amarela foi acionado	
	else if(buffer_comando[pos_c] == 'y') {
		remover_buffer_comando();
		*pt_udr0 = '\n';
		flag = 3;//mensagem referente ao comando da cor amarelo
			(*pt_portb) = led[4]; //led amarelo
	}
	//checa se o comando referente a cor ciano foi acionado
	else if(buffer_comando[pos_c] == 'c') {
			remover_buffer_comando();
			*pt_udr0 = '\n';
			flag = 4;	//mensagem referente ao comando da cor ciano
			(*pt_portb) = led[5]; //led ciano
	}
	//checa se o comando referente a cor magenta foi acionado	
	else if(buffer_comando[pos_c] == 'm') {
			remover_buffer_comando();
			*pt_udr0 = '\n';
			flag = 5;	//mensagem referente ao comando da cor magenta
			(*pt_portb) = led[6]; //led magenta
	}
//checa se o comando referente a cor branca foi acionado
	else if(buffer_comando[pos_c] == 'w') {
				remover_buffer_comando();
				*pt_udr0 = '\n';
				flag = 6;	//mensagem referente ao comando da cor branca
			(*pt_portb) = led[7]; //led branco
	}
//checa se um comando invalido foi acionado
	else {
			remover_buffer_comando();
				*pt_udr0 = '\n';
				flag = 7; //mensagem referente a um comando invalido 
			(*pt_portb) = led[0]; // led apagado
				
}

_delay_ms(200);
(*pt_portb) = led[0];	//apaga o led
		}

	}

}