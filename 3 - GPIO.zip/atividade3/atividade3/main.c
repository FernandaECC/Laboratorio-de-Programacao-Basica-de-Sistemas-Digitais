
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

//Configura��es iniciais para ativar o pull up e definir o pino A0 como entrada
unsigned char *pt_ddrc = (unsigned char*) 0x27; //define dire��o de dados
unsigned char *pt_pinc = (unsigned char*) 0x26; //define leitura ou escrita de informa��o
unsigned char *pt_portc = (unsigned char*) 0x28; //para ativar o pull-up o portc deve ser setado no pino que irei usar
unsigned char *mcucr = (unsigned char*) 0x55; //MCU Control Register --> vari�vel global usada para ativar o pull-up interno
unsigned char *ucsr0b = 0xC1; //registrador de controle e status de USART
unsigned char *ddrd = 0x2A; //define dire��o de dados
unsigned char *portd = 0x2B; //ser�o utilizadas as portas D para cada segmento do display


int main()
{
	unsigned char mask_portc = 0x01; //defini��o de uma vari�vel para atribu�-la a um ponteiro (PORTC)
	unsigned char mask_ddrd = 0b11111110; // defini��o de quais portas D ser�o utilizadas para o display
	unsigned char PC_mask = 0x01; //defini��o de uma vari�vel para poder realizar compara��es
	
	// foi adicionado ao decoder os valores referentes a 0 a 9 no display de 7 segmentos
	unsigned char decoder[10] = {
		0x7e, 0x0c, 0xb6, 0x9e, 0xcc, 0xda, 0xfa, 0x0e, 0xfe, 0xde
	};
	
	//defini��o de duas vari�veis que receberam o conte�do do ponteiro referente ao estado do bot�o
	unsigned char PC;
	unsigned char PC_2;
	int state = 0; //defini��o do estado inicial do decoder
	unsigned char mask_ddrc = 0xFE; //defini��o de uma vari�vel para atribu�-la a um ponteiro (DDRC)
	(*pt_ddrc) &= mask_ddrc; // definida como entrada pois ir� receber informa��es do bot�o
	
	*mcucr = *mcucr & 0xEF; //deve-se zerar o bit 4 para ativar o pull-up
	
	(*pt_portc) |= mask_portc; // segunda configura��o para ativar o pull up, isto �, PORTC deve ter o valor 0x01
	
	(*ddrd) |= mask_ddrd; //atribui ao endere�o apontado o valor de mask_ddrd, definindo assim as portas que ser�o utilizadas pelo display
	(*ucsr0b) &= ~(0x08); //desativa TX (fun��o serial do receptor) de PD1

	
	(*portd) = decoder[state]; //inicialmente, como n�o houve nenhum pressionamento do bot�o, o valor que deve ser exibido
	//no display deve ser 0

	unsigned char anterior; //defini��o de uma vari�vel que receber� o estado do bot�o sempre um pouco antes de um poss�vel pressionamento deste
	
	while(1)
	{
		anterior = *pt_pinc;//realiza a primeira checagem do estado do bot�o, um momento antes do poss�vel pressionamento do bot�o
		_delay_ms(100);//espera um tempo para cessar o efeito debouncing
		PC = *pt_pinc;//efetua a segunda checagem do bot�o, em um breve momento posterior
		//no segundo IF, realiza uma nova checagem do bot�o, para verificar se este foi de fato pressionado
		//caso tenha sido pressionado e anteriormente nao (ANERIOR igual a 1), o display deve avan�ar para o pr�ximo numero apos verificar que houve alteracao neste segundo IF
		
		if((PC & PC_mask) == 0x00) {
			
			PC_2 = *pt_pinc;
			
			if((PC_2 & PC_mask) == 0x00 && anterior == 0x01) {

				state = (state + 1) % 10;
				(*portd) = decoder[state];


			}
		}
		
		
	}
	return 0;
}