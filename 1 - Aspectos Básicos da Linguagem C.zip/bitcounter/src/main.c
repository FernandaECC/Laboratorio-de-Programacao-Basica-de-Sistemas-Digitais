/* Contador de bits
 *
 * Este programa conta o numero de bits em um byte
 */

#include <stdio.h>

int main() {

  unsigned char entrada;
  unsigned int tmp;
  unsigned int n_bits;

  /* Ler entrada em hexadecimal */
  scanf("%x", &tmp);
  entrada = (unsigned char)tmp;


  n_bits = 0;
 /*Realiza-se um AND entre o valor de entrada e o valor 0x01 para verificar se o LSB é igual a 1*/
 /*Caso seja igual a um, icrementa-se a variável n_bits*/
/*Em seguida, desloca-se o valor de entrada em um bit para a direita, independentemente do resultado analisado acima*/
/*Repete-se o processo até que a variável entraada seja igual a zero.*/
  while(entrada != 0) {
    if((entrada & 1) == 1) {
      n_bits++;
    }
  entrada = entrada >> 1;
  }

  /* Escrever numero de bits */
  printf("%d\n", n_bits);
  return 0;
}
