/*
 * atividade6.c
 *
 * Created: 04/10/2019 10:00:11
 * Author : Fernanda Esteves
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
//Cria-se ponteiros para cada registrador referente a USART que deve ser configurado para a transmissao da mensagem 
unsigned char *pt_ubrr0h = (unsigned char*) 0xC5;
unsigned char *pt_ubrr0l = (unsigned char*) 0xC4;
unsigned char *pt_ucsr0a = (unsigned char*) 0xC0;
unsigned char *pt_ucsr0b = (unsigned char*) 0xC1;
unsigned char *pt_ucsr0c = (unsigned char*) 0xC2;
unsigned char *pt_udr0 = (unsigned char*) 0xC6;

int main () {
	//Para definir o baund rate deve-se configurar o registrador UBRR0 do seguinte modo:
	//UBRR0H = 0;
	*pt_ubrr0h = *pt_ubrr0h & 0xF0;
	//UBRR0L = 0b00011001;
	*pt_ubrr0l = 0b00011001;
	
	//Para desabilitar o double speed e o modo de comunica��o multi-processador deve-se zerar os bits 1 e 0 do registrador UCSR0A
	//UCSR0A = 0x00;
	*pt_ucsr0a = *pt_ucsr0a & 0xFC;
	
	//Para desabilitar as interrupcoes referentes a USART, deve-se zerar os bits 7, 6 e 5 do registrador UCSR0B
	//Para desabilitar o receptor o bit 4 do registrador UCSR0B deve ser zerado
	//Para habilitar o transmissor o bit 3 do registrador UCSR0B deve ser setado
	// o bit se refere ao numero de bits de dados de um frame
	//Os bits 1 e 0 se referem ao nono bit, portanto nao temos interesse em seus valores
	// UCSR0B = 0b00001000;
	*pt_ucsr0b = *pt_ucsr0b & 0x0A; //setar  o registrador UCSR0B
	*pt_ucsr0b = *pt_ucsr0b | 0x08; //resetar o registrador UCSR0B
	
	//os bits 7 e 6 do registrador UCSR0C definem o modo de operacao da USART (nesse caso, devem ser 0 ambos para ser assincrono)
	//os bits 5 e 4 do registrador UCSR0C definem o uso ou n�o de bit bit de paridade e seu tipo (nesse caso, desejamos paridade impar por isso ambos serao 1)
	// o bit 3 define o numero de bits de parada - neste caso sera 1, portando o bit 3 deve ser zerado
	//os bits 2 e 1 do registrador UCSR0C, juntamente com o bit 2 de UCSR0B, definem o numero de bits de dados de um frame - neste caso 8, portanto devem ser 011, respectivamente
	// UCSR0C = 0b00110110;
	*pt_ucsr0c = 0b00110110;

//declaracao de variaveis contadores que auxiliarao na execucao do programa
	int count_1 = 0;
	int count_2 = 0;
	int flag = 0; // mostrara quando a mensagem chegou ao seu fim
	
	//vetor com a mensagem
	char caractere[] = " Out of the night that covers me,\n Black as the Pit from pole to pole,\n I thank whatever gods may be\n For my unconquerable soul.\n In the fell clutch of circumstance\n I have not winced nor cried aloud.\n Under the bludgeonings of chance\n My head is bloody, but unbowed.\n Beyond this place of wrath and tears\n Looms but the Horror of the shade,\n And yet the menace of the years\n Finds, and shall find, me unafraid.\n It matters not how strait the gate,\n How charged with punishments the scroll.\n I am the master of my fate:\n I am the captain of my soul.\n ";
//vetor com o aviso final
	char mens_final[] = " Mensagem transmitida com sucesso! \n";
	
	while(1) {
		//verifica se o buffer de transmissao UDR0 esta pronto para receber novos dados e se a mensagem nao chegou ao fim
		while ((UCSR0A & 0x20) && !flag) {
			//se chegou ao fim da mensagem, flag e setada e um enter e dado
			//alem disso, a variavel que percorre o vetor da mensagem e zerada para recomecar o envio da mensagem
			if(caractere[count_1] == '\0') {
				flag = 1;
				 *pt_udr0 = '\n'; 
				 count_1 = 0;
				
			}
			//se nao chegou ao fim da mensagem, sera enviado caractere por caractere ao buffer de transmissao UDR0
			else {
				*pt_udr0 = caractere[count_1];
				count_1 = count_1 + 1;
			}
		}
	//verifica se o buffer de transmissao UDR0 esta pronto para receber novos dados e se a mensagem chegou ao fim
		while( (UCSR0A & 0x20) && flag) {
			//verifica se a mensagem final j� foi enviada
			// se sim , um enter e um delay sao dados e a variavel que percorre o vetor da mensagem final e zerada para recomecar o envio desta
			//e a flag que indica que a mensagem principal chegou ao fim � zerada para que possa envia-la novamente
			if(mens_final[count_2]== '\0') {
				*pt_udr0 = '\n';
				_delay_ms(5000);
				count_2 = 0;
				flag = 0;
			}
			//se nao chegou ao fim da mensagem final, sera enviado caractere por caractere ao buffer de transmissao UDR0
			else{
				*pt_udr0 = mens_final[count_2];
				count_2 = count_2 + 1;
			}
			
		}
	}
	
	return 0;
}

