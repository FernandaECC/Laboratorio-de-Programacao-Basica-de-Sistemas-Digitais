#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
//Cria-se ponteiros para cada registrador referente a USART que deve ser configurado para a transmissao da mensagem bem como para a porta utizada pelo led
unsigned char *pt_ubrr0h = (unsigned char*) 0xC5;
unsigned char *pt_ubrr0l = (unsigned char*) 0xC4;
unsigned char *pt_ucsr0a = (unsigned char*) 0xC0;
unsigned char *pt_ucsr0b = (unsigned char*) 0xC1;
unsigned char *pt_ucsr0c = (unsigned char*) 0xC2;
unsigned char *pt_udr0 = (unsigned char*) 0xC6;

//configuracoes referentes ao led
unsigned char *pt_ddrb = (unsigned char*) 0x24;
unsigned char *pt_portb = (unsigned char*) 0x25;

//Configuracao dos valores dos registradores referentes ao temporizador
unsigned char *pt_ocr2a = (unsigned char*) 0xB3;
unsigned char *pt_tccr2a = (unsigned char*) 0xB0;
unsigned char *pt_tccr2b = (unsigned char*) 0xB1;
unsigned char *pt_timsk2 = (unsigned char*) 0x70;



//variaveis referentes as mensagens
volatile int count_msg = 0;
volatile int mensagem_enviada = 0;
volatile int onda = 0;
volatile int comando = 0;
// 0 --> sem forma de onda
// 1 --> onda senoidal
// 2 --> onda triangular
// 3 --> onda dente-de-serra
// 4 --> onda AM

//variaveis referentes ao tempo e amostras
volatile unsigned int count = 0;
volatile unsigned int count_amostra = 0;
volatile unsigned int aux_led = 0;


char mensagens[5][40] = {"Nenhuma forma de onda selecionada\n\0", "Onda senoidal\n\0", "Onda triangular\n\0", "Onda dente-de-serra\n\0", "Onda AM\n\0"};
//vetores de amostras
char dente_serra[200] = {0, 1, 3, 4, 5, 6, 8, 9, 10, 11, 13, 14, 15, 17, 18, 19, 20, 22, 23, 24, 26, 27, 28, 29, 31, 32, 33, 34, 36, 37, 38, 40, 41, 42, 43, 45, 46, 47, 48, 50, 51, 52, 54, 55, 56, 57, 59, 60, 61, 62, 64, 65, 66, 68, 69, 70, 71, 73, 74, 75, 77, 78, 79, 80, 82, 83, 84, 85, 87, 88, 89, 91, 92, 93, 94, 96, 97, 98, 99, 101, 102, 103, 105, 106, 107, 108, 110, 111, 112, 113, 115, 116, 117, 119, 120, 121, 122, 124, 125, 126, 128, 129, 130, 131, 133, 134, 135, 136, 138, 139, 140, 142, 143, 144, 145, 147, 148, 149, 150, 152, 153, 154, 156, 157, 158, 159, 161, 162, 163, 164, 166, 167, 168, 170, 171, 172, 173, 175, 176, 177, 179, 180, 181, 182, 184, 185, 186, 187, 189, 190, 191, 193, 194, 195, 196, 198, 199, 200, 201, 203, 204, 205, 207, 208, 209, 210, 212, 213, 214, 215, 217, 218, 219, 221, 222, 223, 224, 226, 227, 228, 230, 231, 232, 233, 235, 236, 237, 238, 240, 241, 242, 244, 245, 246, 247, 249, 250, 251, 252, 254};
char triangular[200] = {0, 2, 4, 7, 9, 12, 14, 17, 19, 22, 25, 27, 30, 32, 35, 37, 40, 43, 45, 48, 50, 53, 55, 58, 60, 63, 66, 68, 71, 73, 76, 78, 81, 83, 86, 89, 91, 94, 96, 99, 101, 104, 107, 109, 112, 114, 117, 119, 122, 124, 127, 130, 132, 135, 137, 140, 142, 145, 147, 150, 153, 155, 158, 160, 163, 165, 168, 171, 173, 176, 178, 181, 183, 186, 188, 191, 194, 196, 199, 201, 204, 206, 209, 211, 214, 217, 219, 222, 224, 227, 229, 232, 235, 237, 240, 242, 245, 247, 250, 252, 255, 255, 252, 250, 247, 245, 242, 240, 237, 235, 232, 229, 227, 224, 222, 219, 217, 214, 211, 209, 206, 204, 201, 199, 196, 194, 191, 188, 186, 183, 181, 178, 176, 173, 171, 168, 165, 163, 160, 158, 155, 153, 150, 147, 145, 142, 140, 137, 135, 132, 130, 127, 124, 122, 119, 117, 114, 112, 109, 107, 104, 101, 99, 96, 94, 91, 89, 86, 83, 81, 78, 76, 73, 71, 68, 66, 63, 60, 58, 55, 53, 50, 48, 45, 43, 40, 37, 35, 32, 30, 27, 25, 22, 19, 17, 14, 12, 9, 7, 4};
char senoidal[200] = {127, 131, 135, 139, 143, 147, 151, 155, 159, 163, 167, 170, 174, 178, 181, 185, 189, 192, 196, 199, 202, 205, 209, 212, 215, 217, 220, 223, 226, 228, 231, 233, 235, 237, 239, 241, 243, 244, 246, 247, 249, 250, 251, 252, 253, 253, 254, 254, 255, 255, 255, 255, 255, 254, 254, 253, 253, 252, 251, 250, 249, 247, 246, 245, 243, 241, 239, 237, 235, 233, 231, 228, 226, 223, 220, 218, 215, 212, 209, 206, 202, 199, 196, 192, 189, 185, 182, 178, 174, 171, 167, 163, 159, 155, 151, 147, 143, 139, 135, 131, 127, 123, 119, 115, 111, 107, 103, 99, 95, 92, 88, 84, 80, 76, 73, 69, 66, 62, 59, 55, 52, 49, 46, 43, 40, 37, 34, 31, 29, 26, 24, 21, 19, 17, 15, 13, 11, 10, 8, 7, 5, 4, 3, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 15, 17, 19, 21, 23, 26, 28, 31, 33, 36, 39, 42, 45, 48, 51, 55, 58, 62, 65, 69, 72, 76, 80, 83, 87, 91, 95, 99, 103, 107, 111, 115, 119, 123};
char am[200] = {128, 141, 155, 168, 181, 192, 203, 211, 218, 223, 226, 226, 223, 218, 211, 201, 189, 176, 161, 145, 128, 110, 93, 76, 60, 46, 34, 23, 16, 10, 8, 9, 13, 19, 29, 41, 55, 71, 89, 108, 127, 147, 166, 185, 202, 217, 230, 241, 249, 253, 255, 253, 249, 241, 230, 217, 202, 185, 166, 147, 128, 108, 89, 71, 55, 41, 29, 19, 13, 9, 8, 10, 16, 23, 34, 46, 60, 76, 93, 110, 127, 145, 161, 176, 189, 201, 211, 218, 223, 226, 226, 223, 218, 211, 203, 192, 181, 168, 155, 141, 128, 114, 102, 91, 81, 72, 65, 60, 57, 55, 56, 58, 62, 67, 73, 81, 90, 99, 108, 118, 127, 137, 145, 153, 160, 166, 171, 175, 177, 178, 178, 177, 174, 171, 166, 161, 155, 148, 142, 135, 128, 121, 114, 108, 102, 97, 93, 89, 87, 86, 85, 86, 87, 89, 93, 97, 102, 108, 114, 121, 127, 135, 142, 148, 155, 161, 166, 171, 174, 177, 178, 178, 177, 175, 171, 166, 160, 153, 145, 137, 128, 118, 108, 99, 90, 81, 73, 67, 62, 58, 56, 55, 57, 60, 65, 72, 81, 91, 102, 114};

//interrupcao referente a recepcao da mensagem na uart
ISR(USART_RX_vect) {
	comando = *pt_udr0; //recebe a ordem digitada na uart
	if(comando == 's'){
		//onda senoidal --- segundo elemento do vetor de mensagens
		onda = 1;
		*pt_udr0 = '\0';
	}
	else if(comando == 't'){
		//onda triangular --- terceiro elemento do vetor de mensagens
		onda = 2;
		*pt_udr0 = '\0';
	}
	else if(comando== 'd'){
		//onda dente-de-serra --- quarto elemento do vetor de mensagens
		onda = 3;
		*pt_udr0 = '\0';
	}
	else if(comando == 'a'){
		//onda AM --- quinto elemento do vetor de mensagens
		onda = 4;
		*pt_udr0 = '\0';
	}
	else{
		//Sem sinal de onda --- primeiro elemento do vetor de mensagens
		onda = 0;
		*pt_udr0 = '\0';
	}
	
};
//interrupcao referente a transmissao da mensagem na uart
ISR(USART_TX_vect){

	if(mensagens[onda][count_msg] != '\0'){
		(*pt_udr0) = mensagens[onda][count_msg];//transmite a mensagem de acordo com o comando recebido
		count_msg = count_msg + 1;
	}
	else{
		//ao chegar ao fim, volta a zero o ponteiro que percorre cada mensagem
	count_msg = 0;}
	
};
//piscar led e gerar s onda
ISR(TIMER2_OVF_vect){
	count = count + 1; //variavel contadora que e incrementada a cada 16us

	if(comando == 's'){
		//sera enviada cada amostra ao OCR2A para formar a onda senoidal
		*pt_ocr2a = senoidal[count_amostra];
		count_amostra = (count_amostra + 1);
		//Para fazer o led piscar por 1s e necessario que ocorra a interrupcao por overflow 62500
		if((count >= 62500) & (aux_led == 0)){
			count = 0;
			*pt_portb = *pt_portb & 0xdf; //apaga o led
			aux_led = 1;
		}
		if((count >= 62500) & (aux_led == 1)){
			count = 0;
			*pt_portb = *pt_portb | 0x20; //acende o led
			aux_led = 0;
		}

	}
	else if(comando == 't'){
		//sera enviada cada amostra ao OCR2A para formar a onda triangular
		*pt_ocr2a = triangular[count_amostra];
		count_amostra = (count_amostra + 1);
		//Para fazer o led piscar por 1s e necessario que ocorra a interrupcao por overflow 31250
		if((count >= 31250) & (aux_led == 0)){
			count = 0;
			aux_led = 1;
			*pt_portb = *pt_portb & 0xdf; //apaga o led
		}
		if((count >= 31250) & (aux_led == 1)){
			count = 0;
			aux_led = 0;
			*pt_portb = *pt_portb | 0x20; //acende o led
		}

	}
	else if(comando == 'd'){
		//sera enviada cada amostra ao OCR2A para formar a onda dente-de-serra
		*pt_ocr2a = dente_serra[count_amostra];
		count_amostra = (count_amostra + 1);
		//Para fazer o led piscar por 1s e necessario que ocorra a interrupcao por overflow 15625
		if((count >= 15625) & (aux_led == 0)){
			count = 0;
			aux_led = 1;
			*pt_portb = *pt_portb & 0xdf; //apaga o led
		}
		if((count >= 15625) & (aux_led == 1)){
			count = 0;
			aux_led = 0;
			*pt_portb = *pt_portb | 0x20; //apaga o led
		}

	}
	else if(comando == 'a'){
		//sera enviada cada amostra ao OCR2A para formar a onda AM
		*pt_ocr2a = am[count_amostra];
		count_amostra = (count_amostra + 1);
		//Para fazer o led piscar por 1s e necessario que ocorra a interrupcao por overflow 7813
		if((count >= 7813) & (aux_led == 0)){
			count = 0;
			aux_led = 1;
			*pt_portb = *pt_portb & 0xdf; //apaga o led
		}
		if((count >= 7813) & (aux_led == 1)){
			count = 0;
			aux_led = 0;
			*pt_portb = *pt_portb | 0x20; //acende o led
		}
		
	}
	else{//sem um comando valido, o led deve permanecer apagado
		*pt_ocr2a = 0;
		*pt_portb = *pt_portb & 0xdf;
	}
	//quando for percorrido todo o vetor de amostra, deve-se voltar a posicao inicial
	if(count_amostra == 200){
		count_amostra = 0;
	}
}

int main () {
	//Para definir o baund rate deve-se configurar o registrador UBRR0 do seguinte modo:
	//UBRR0H = 0;
	*pt_ubrr0h = *pt_ubrr0h & 0xF0;
	//UBRR0L = 0b01100111;
	*pt_ubrr0l = 0b01100111;
	
	//Para desabilitar o double speed e o modo de comunicacao multi-processador deve-se zerar os bits 1 e 0 do registrador UCSR0A
	//UCSR0A = 0x00;
	*pt_ucsr0a = *pt_ucsr0a & 0b11111100;
	
	//Para habilitar a recepcao e transmissao completa bem como o receptor e o transmissor configura-se UCSR0B da seguinte forma: 1101 1000
	*pt_ucsr0b = 0xD8;
	
	//Para que o modo de operacao da usart seja assincrono, nao tenha bit de paridade, use 2 bits de parada e tenha um frame de 8 bits configura-se UCSR0C da seguinte forma: 0b00001110;
	*pt_ucsr0c = 0x0e;
	//Para configurar os pinos da porta B como pinos de entrada
	*pt_ddrb = 0x28;
	//Habita-se todas as interrupcoes globais
	sei();

	//configuro para o modo FAST PWM
	*pt_tccr2a = 0x83;
	*pt_tccr2b = 0x01;
	//ativo o modo de overflow
	*pt_timsk2 = *pt_timsk2 | 0b00000001;

	//desse modo, a cada interrupcao de overflow tera se passado 16us
	
	*pt_portb |= 0x20; // acende o LED


	while(1){}
}

