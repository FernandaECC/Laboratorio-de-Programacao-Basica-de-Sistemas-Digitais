#include <avr/io.h>
#include <avr/interrupt.h>



extern void atraso (short int q);

//variaveis auxiliares para a checagem do botao b
unsigned char B_mask = 0x01;
unsigned char est_atual_B;

volatile char flag;
//vetor referente ao bot?o A
short int tempo[4] = {
	1000, 500, 250, 125
};

//vetor referente ao botao B - sentido horario
unsigned char cores[8] = {
	0x00, 0x01, 0x02, 0x04, 0x03, 0x06, 0x05, 0x07
};



unsigned char *pt_ddrb = (unsigned char*) 0x24; //registrador de direcao de dados referente a porta B
unsigned char *pt_portb = (unsigned char*) 0x25; //registrador de dados referente as portas B
unsigned char *pt_ddrc = (unsigned char*) 0x27; //registrador de direcao de dados referente a porta C
unsigned char *pt_pinc = (unsigned char*) 0x26; //O endere?o dos pinos de entrada da porta C
unsigned char *pt_ddrd = (unsigned char*) 0x2a; //registrador de direcao de dados referente a porta D
unsigned char *pt_pind = (unsigned char*) 0x29; //O endere?o dos pinos de entrada da porta D
unsigned char *ptpcicr = (unsigned char*) 0x68; // registrador PCICR
unsigned char *ptpcmsk1 = (unsigned char*) 0x6c; // registrador PCMSK1

//variaveis auxiliares para definir o tempo, a cor do led e o sentido da maquina de estados
volatile int state_A = 0;
volatile int state_B = 0;
volatile int sentido = 0;

//variavel para definir o tempo em milisegundos do atraso
volatile short int tempo_atual;

//ao ocorrer a solicitacao de uma interrupcao, deve-se estabelecer o que vai ocorrer
//interrupcao botao A
ISR(INT0_vect) {
	state_A = ((state_A + 1) % 4);
};

//interrupcao botao B
ISR(PCINT1_vect) {
	est_atual_B = *pt_pinc;

	if((est_atual_B & B_mask) == 0x00) {
		sentido = (sentido + 1) % 2;
	}
};

int main () {
	//configuracoes dos pinos
	*pt_ddrb  = *pt_ddrb | 0x07;
	*pt_ddrc = *pt_ddrc & 0xFE;
	*pt_ddrd = *pt_ddrd & 0xFB;
	//configuracoes referentes ao botao A: borda de subida e ativacao da interrupcao
	EICRA |= (1 <<ISC00);
	EICRA |= (1 <<ISC01);
	EIMSK |= (1 << INT0);


	//configuracoes referentes ao botao B: pin change e ativacao da interrupcao de PCINT8
	*ptpcicr = *ptpcicr | 0x02;
	*ptpcmsk1 = *ptpcmsk1 | 0x01;

	sei();

	while(1) {
		//sentido = 1 --> anti-horario
		if(sentido == 1) {
			state_B = (state_B + 1) % 8;
		}
		//sentido = 0 --> horario
		else {
			state_B = (state_B - 1);
			if (state_B < 0) state_B = 7;
		}

		(*pt_portb) = cores[state_B];

		tempo_atual = tempo[state_A];
		atraso(tempo_atual);
	}
	return 0;
}