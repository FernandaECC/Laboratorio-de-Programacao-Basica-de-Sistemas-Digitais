#include <stdio.h>

char buffer[5];  // declaraçao do buffer (vetor)
int next = 0; //proxima posiçao livre para gravar
int pos = 0; // posição do elemento mais antigo
int count = 0; // variável contadora que será incrementada caso seja adicionado algo no vetor e decrementada caso algo seja apagado do vetor

void adicionar_buffer(char c) {
  if (!(next == pos && count == 5)) {//checa se o vetor está cheio; senão entra no if para adicionar elementos
      buffer[next] = c;
      next = (next+1) % 5;
    //esta operação acima faz com que o vetor next avance uma casa apos adicionar algo ao vetor, porém de forma circular
      // assim ao efetuar tal operação, é atribuido a next o resto da divisao entre next+1 e 5, pois quando next estiver na
      //untima posição, deve voltar ao inicio do vetor
      count++;
//incrementa a variável contadora toda vez que algo é adicionado ao vetor
  }
}

void remover_buffer() {
  if(!(next == pos && count == 0)) {//checa se o buffer está vazio; senão, entra no if para remover itens
    pos = (pos+1) % 5;//avança com a posição do mais antigo item do vetor
    count--;
// decresce a variável contadora que indica o numero de itens no vetor, já que algo será removido
  }
}

void imprimir_buffer() {
// Haverá 2 casos para imprimir: 1) buffer vazio; 2) buffer cheio ou buffer com algo, porém não está cheio
  int aux;
  int sub;
  int i;
  //1º caso: buffer vazio
  if (next == pos && count == 0) { //verifica se o vetor está vazio
    printf("\n"); //se estiver, printar só \n
  } 
  
  //2°caso: buffer cheio ou com algo porém não cheio
  else {
    aux = pos;
    
    for (i = 0; i < count; i++) { //queremos que seja impresso o valor desde a posição mais antiga (pos) até a mais atual, imprimindo somente os números presentes no vetor (indicado por count)
      if (i == count-1) {
        printf("%c", buffer[aux]); //printar o ultimo elemento sem espaço
        printf("\n");
      } else {
        printf("%c ", buffer[aux]);
      }
      aux = (aux+1)%5; //avança circulamente
    }
  }
}

int main() {

  char c;

  do {
    scanf("%c", &c);//lê a entrada  
  if (c == '\n') {//caso a entrada seja \n (enter) o programa deve parar (chegou ao fim da linha/entrada)
    break;
  }
    
  /* Sugestao: aqui deveria vir o seu codigo */ 
    
	
  if(c>='0' && c<='9') {//verifica se a entrada é um número;  caso seja, irá adicioná-lo no vetor caso este não esteja cheio
    adicionar_buffer(c);
}

  else { //caso a entrada não for um número, será uma letra e, portanto o item mais antigo do vetor deverá ser removido caso o vetor não esteja vazio
    remover_buffer();
  }

  imprimir_buffer();//a cada irteração, sempre deverá ser impresso o conteúdo do vetor
    
  } while (1);

  return 0;
}
