/*
 * atividade8.c
 *
 * Created: 30/10/2019 09:45:16
 * Author : Fernanda Esteves RA: 215835
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
//Cria-se ponteiros para cada registrador referente a USART que deve ser configurado para a transmissao da mensagem
unsigned char *pt_ubrr0h = (unsigned char*) 0xC5;
unsigned char *pt_ubrr0l = (unsigned char*) 0xC4;
unsigned char *pt_ucsr0a = (unsigned char*) 0xC0;
unsigned char *pt_ucsr0b = (unsigned char*) 0xC1;
unsigned char *pt_ucsr0c = (unsigned char*) 0xC2;
unsigned char *pt_udr0 = (unsigned char*) 0xC6;

//Configuracao dos valores dos registradores referentes ao temporizador
unsigned char *pt_ocr2a = (unsigned char*) 0xB3;
unsigned char *pt_tccr2a = (unsigned char*) 0xB0;
unsigned char *pt_tccr2b = (unsigned char*) 0xB1;
unsigned char *pt_timsk2 = (unsigned char*) 0x70;

//ponteiros referentes aos pinos dos leds (da placa e externo)
unsigned char *pt_ddrb = (unsigned char*) 0x24;
unsigned char *pt_portb =(unsigned char*) 0x25;

//Efetuando o c�lculo da formula dada em aula para descobrir um valor de faixa, foi obtido tal valor
//com um prescaler igual a 64 e um limite de 250, assim: faixa = 64*250/(16*10^6) = 1*10^-3 s
//Desse modo, sera necessario repetir 500 vezes a interrupcao para o led da placa e 780 vees para o led externo.



//declaracao de variaveis referentes ao estado dos leds, a contagem de faixas e a faixa limite de acordo com a equacao dada em aula
volatile int estado_led_placa = 0;
volatile int estado_led_externo = 0;
int count_led_placa = 0;
int count_led_externo = 0;
//conforme citado anteriormente, definiu-se os limites para o numero de interrupcoes que devem ocorrer para se obter o periodo de tempo desejado
//para cada led
const int max_count_led_placa = 500;
const int max_count_led_externo = 780;

//funcao relativa a piscagem do led do arduino
void piscagem_led_placa(){
	//se estiver apagado, deve-se acende-lo
	if(estado_led_placa == 0) {
		*pt_portb |= 0X20;
		estado_led_placa = 1;
	}
	//se estiver aceso, deve-se apaga-lo
	else if(estado_led_placa == 1){
		*pt_portb &= 0XDF;
		estado_led_placa = 0;
	}
}
//funcao relativa a piscagem do led externo
void piscagem_led_externo(){
	//se estiver apagado, deve-se acende-lo
	if(estado_led_externo == 0) {
		*pt_portb |= 0x10;
		estado_led_externo = 1;
	}
	//se estiver aceso, deve-se apaga-lo
	else if(estado_led_externo == 1){
		*pt_portb &= 0XEF;
		estado_led_externo = 0;
	}
}


//funcao de interrupcao externa
ISR(TIMER2_COMPA_vect){
	//incrementa toda vez que se passa uma faixa e a interrupcao e acionada
	count_led_placa++;
	count_led_externo++;
	//caso o contador de faixas tenha atigindo o limite, foi obtido o periodo de tempo desejado.
	//Assim, o led deve piscar e a contagem de faixas deve ser reiniciada
	if(count_led_externo > max_count_led_externo) {
		piscagem_led_externo();
		count_led_externo = 0;
	}
	
	if(count_led_placa > max_count_led_placa) {
		piscagem_led_placa();
		count_led_placa = 0;
	}

}


int main () {
	//Para definir o baund rate deve-se configurar o registrador UBRR0 do seguinte modo:
	//UBRR0H = 0;
	*pt_ubrr0h = *pt_ubrr0h & 0xF0;
	//UBRR0L = 0b00011001;
	*pt_ubrr0l = 0b00011001;
	
	//Para desabilitar o double speed e o modo de comunicacao multi-processador deve-se zerar os bits 1 e 0 do registrador UCSR0A
	//UCSR0A = 0x00;
	*pt_ucsr0a = *pt_ucsr0a & 0xFD;
	
	//Para desabilitar as interrupcoes referentes a USART, deve-se zerar os bits 7, 6 e 5 do registrador UCSR0B
	//Para desabilitar o receptor o bit 4 do registrador UCSR0B deve ser zerado
	//Para habilitar o transmissor o bit 3 do registrador UCSR0B deve ser setado
	// o bit se refere ao numero de bits de dados de um frame
	//Os bits 1 e 0 se referem ao nono bit, portanto nao temos interesse em seus valores
	// UCSR0B = 0b00001000;
	*pt_ucsr0b = *pt_ucsr0b & 0x0A; //setar  o registrador UCSR0B
	*pt_ucsr0b = *pt_ucsr0b | 0x08; //resetar o registrador UCSR0B
	
	//os bits 7 e 6 do registrador UCSR0C definem o modo de operacao da USART (nesse caso, devem ser 0 ambos para ser assincrono)
	//os bits 5 e 4 do registrador UCSR0C definem o uso ou nao de bit bit de paridade e seu tipo (nesse caso, desejamos paridade impar por isso ambos serao 1)
	// o bit 3 define o numero de bits de parada - neste caso sera 1, portando o bit 3 deve ser zerado
	//os bits 2 e 1 do registrador UCSR0C, juntamente com o bit 2 de UCSR0B, definem o numero de bits de dados de um frame - neste caso 8, portanto devem ser 011, respectivamente
	// UCSR0C = 0b00110110;
	*pt_ucsr0c = 0b00110110;

	//ativa todas as interrupcoes globais
	sei();

	//Como foi dito acima, a cada 250 contagens ocorre uma interrupcao, o que indica que se passou 1ms. Assim, deve-se atribuir ao
	//registrador de comparacao da saida OCR2A o valor de 250
	*pt_ocr2a = 0xF9;
	//Configuracao do prescaler bem como do mode de operacao Clear Timer on Compare Match (CTC) dos rgistradores de controle do temporizador do timer2
	*pt_tccr2a = *pt_tccr2a | 0b00000010;
	*pt_tccr2b = *pt_tccr2b | 0b00000100;

	//Habilita a comparacao solicitada
	*pt_timsk2 = *pt_timsk2 | 0b00000010;

	//define os pinos da porta B como pinos de saida
	*pt_ddrb = 0x30;

	//vetor da mensagem a ser transmitida
	char msg[] = " Atividade 8 � Interrupcoes temporizadas tratam concorrencia entre tarefas! \n";

	//variavel que percorrera o vetor da mensagem para envia-la a UDR0
	volatile int count_msg = 0;

	while(1) {
		//verifica se o buffer de transmissao UDR0 esta pronto para receber novos dados e se a mensagem nao chegou ao fim
		while( (UCSR0A & 0x20)) {
			//verifica se a mensagem final ja foi enviada
			// se sim , um enter e um delay sao dados e a variavel que percorre o vetor da mensagem final e zerada para recomecar o envio desta
			//e a flag que indica que a mensagem principal chegou ao fim e zerada para que possa envia-la novamente
			if(msg[count_msg]== '\0') {
				*pt_udr0 = '\0';
				_delay_ms(5000);
				count_msg = 0;
				
			}
			//se nao chegou ao fim da mensagem final, sera enviado caractere por caractere ao buffer de transmissao UDR0
			else{
				*pt_udr0 = msg[count_msg];
				count_msg = count_msg + 1;
			}
		}
	}
	return 0;

}









